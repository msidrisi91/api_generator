module.exports = {
    'mongoUrl' : 'mongodb://localhost:27017/conFusion'
}